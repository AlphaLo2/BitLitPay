import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tier, tiers } from "@/types/earn";

export const EarnTab = () => {
  const [activeTab, setActiveTab] = useState<"benefits" | "redeem">("benefits");
  const [activeTier, setActiveTier] = useState<Tier>("welcome");
  const currentTier = tiers[activeTier];

  return (
    <div className="flex flex-col min-h-screen bg-wallet-primary text-white">
      <header className="p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Rewards</h1>
          <Button variant="ghost" className="text-sm text-gray-400">
            See history
          </Button>
        </div>
      </header>

      <main className="flex-1 px-4">
        <div className="mb-6">
          <p className="text-gray-400 text-sm mb-1">YOU ARE ON</p>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2">{currentTier.name}</h2>
              <div className="w-full bg-gray-800 h-1 rounded-full mb-2">
                <div className="bg-wallet-accent h-1 rounded-full w-1/4"></div>
              </div>
              <p className="text-sm text-gray-400">
                Spend 9,998,849 SATS to unlock {activeTier === "welcome" ? "Bronze" : "Next Tier"}
              </p>
            </div>
            <div className="ml-4">
              <div className="h-16 w-16 bg-gray-700 rounded-full flex items-center justify-center">
                <Zap className="h-8 w-8 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        <div className="flex mb-6">
          <button
            className={cn(
              "flex-1 pb-4 text-center border-b-2",
              activeTab === "benefits" 
                ? "border-wallet-accent text-wallet-accent" 
                : "border-gray-800 text-gray-400"
            )}
            onClick={() => setActiveTab("benefits")}
          >
            BENEFITS
          </button>
          <button
            className={cn(
              "flex-1 pb-4 text-center border-b-2",
              activeTab === "redeem" 
                ? "border-wallet-accent text-wallet-accent" 
                : "border-gray-800 text-gray-400"
            )}
            onClick={() => setActiveTab("redeem")}
          >
            REDEEM
          </button>
        </div>

        {activeTab === "benefits" && (
          <div className="space-y-6">
            <div className="space-y-6">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-wallet-warning rounded-full flex items-center justify-center mt-1">
                  <Zap className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">
                    Earn {currentTier.points} Speed points for every 1,000 SATS spent
                  </h3>
                  <p className="text-sm text-gray-400">
                    Earn points when you spend on Speed wallet.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-wallet-accent rounded-full flex items-center justify-center mt-1">
                  <Zap className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">Maximize your savings!</h3>
                  <p className="text-sm text-gray-400">
                    Earn a total of {currentTier.maxPoints.toLocaleString()} points and receive{" "}
                    {currentTier.maxSats.toLocaleString()} SATS as cashback. This is approximately 
                    equivalent to ~₦{currentTier.maxNaira} (the conversion rate depends on the 
                    current market value of BTC).
                  </p>
                </div>
              </div>
            </div>

            <p className="text-xs text-gray-500">
              *To retain the perks of the {currentTier.name}, ensure a minimum monthly 
              transaction of {currentTier.minSpend} SATS; otherwise, your tier and 
              benefits will be downgraded.
            </p>

            <Button 
              className="w-full bg-wallet-accent hover:bg-wallet-accent/90 text-white"
              onClick={() => {}}
            >
              CHECK ALL TIER BENEFITS
            </Button>
          </div>
        )}

        {activeTab === "redeem" && (
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 text-center">
              <h3 className="text-lg mb-4">Redeem all points to Speed Wallet</h3>
              <p className="text-4xl font-bold mb-1">0 SATS</p>
              <p className="text-gray-400 mb-6">~₦0.38</p>
              <Button className="w-full bg-gray-800 text-gray-400" disabled>
                MIN. 40 POINTS TO REDEEM
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};