import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Zap, Key } from "lucide-react";

export const WalletTab = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Wallets</h2>
      
      {/* Custodian Wallet Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Custodial Wallet</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            <Plus className="mr-2" />
            Create Custodial Wallet
          </Button>
        </CardContent>
      </Card>

      {/* Non-Custodian Wallet Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Non-Custodial Wallet</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            <Key className="mr-2" />
            Create Non-Custodial Wallet
          </Button>
        </CardContent>
      </Card>

      {/* Lightning Address Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Lightning Address</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            <Zap className="mr-2" />
            Set Up Lightning Address
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};